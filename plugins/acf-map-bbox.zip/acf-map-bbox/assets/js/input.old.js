(function($, undefined){

	var Field = acf.Field.extend({

		type: 'map_bbox',

		map: false,

		wait: 'load',

		events: {
			'click a[data-name="clear"]': 		'onClickClear',
			'click a[data-name="locate"]': 		'onClickLocate',
			'click a[data-name="search"]': 		'onClickSearch',
			'keydown .search': 					'onKeydownSearch',
			'keyup .search': 					'onKeyupSearch',
			'focus .search': 					'onFocusSearch',
			'blur .search': 					'onBlurSearch',
			'showField':						'onShow',
			'change input[type=radio][name="shape"]': 'onChangeType'
		},

		$control: function(){
			return this.$('.acf-google-map');
		},

		$search: function(){
			return this.$('.search');
		},

		$canvas: function(){
			return this.$('.canvas');
		},

		setState: function( state ){

			// Remove previous state classes.
			this.$control().removeClass( '-value -loading -searching' );

			// Determine auto state based of current value.
			if( state === 'default' ) {
				state = this.val() ? 'value' : '';
			}

			// Update state class.
			if( state ) {
				this.$control().addClass( '-' + state );
			}
		},

		getValue: function(){
			var val = this.$input().val();
			if( val ) {
				val = JSON.parse( val );
				return val;
			} else {
				return false;
			}
		},

		setValue: function( val, silent ) {

			console.log(val);

			// Convert input value.
			var valAttr = '';
			if( val ) {
				valAttr = JSON.stringify( val );
			}

			// Update input (with change).
			acf.val( this.$input(), valAttr );

			// Bail early if silent update.
			if( silent ) {
				return;
			}

			// Render.
			this.renderVal( val );

			/**
			 * Fires immediately after the value has changed.
			 *
			 * @date	12/02/2014
			 * @since	5.0.0
			 *
			 * @param	object|string val The new value.
			 * @param	object map The Google Map isntance.
			 * @param	object field The field instance.
			 */
			acf.doAction('google_map_change', val, this.map, this);
		},

		getShapeInfo: function (coordinates) {
			var paths = [];
			var bounds;
			var using = 'none';

			if(coordinates && coordinates.length) {

				// Determine if a bounding box OR GeoShape
				if(coordinates.length === 2) {
					var sw = coordinates[0];
					var ne = coordinates[1];
					bounds = new google.maps.LatLngBounds(new google.maps.LatLng(sw[1], sw[0]), new google.maps.LatLng(ne[1], ne[0]));

					var line = turf.lineString([[sw[0], sw[1]], [ne[0], ne[1]]]);
					var bbox = turf.bbox(line);
					var bboxPolygon = turf.bboxPolygon(bbox);
					coordinates = bboxPolygon.geometry.coordinates[0];
					coordinates.pop();

					using = 'rectangle';
				} else {
					using = 'polygon';
				}

				coordinates.forEach(lngLat => {
					paths.push({ lat: lngLat[1], lng: lngLat[0] });
				});
			}

			return {
				paths,
				bounds,
				using
			};
		},

		renderVal: function( val ) {

			// Value.
			if( val ) {
				this.setState( 'value' );
				this.$search().val( val.address );
				this.setPosition( val.lat, val.lng, val.coordinates );

				// No value.
			} else {
				this.setState( '' );
				this.$search().val( '' );
				this.map.marker.setVisible( false );
				this.map.rectangle.setMap(null);
				this.map.polygon.setMap(null);
			}
		},

		newLatLng: function( lat, lng ){
			return new google.maps.LatLng( parseFloat(lat), parseFloat(lng) );
		},

		setPosition: function( lat, lng, coordinates ) {

			// Update marker position.
			this.map.marker.setPosition({
				lat: parseFloat(lat),
				lng: parseFloat(lng)
			});

			console.log({coordinates});

			var shapeInfo = this.getShapeInfo(coordinates);

			console.log({shapeInfo});

			if(shapeInfo.using === 'polygon') {
				this.map.polygon.setPaths(shapeInfo.paths);
				this.map.rectangle.setBounds(shapeInfo.bounds);
				this.map.polygon.setMap(this.map);
				this.map.rectangle.setMap(null);
			} else if(shapeInfo.using === 'rectangle') {
				this.map.polygon.setPaths(shapeInfo.paths);
				this.map.rectangle.setBounds(shapeInfo.bounds);
				this.map.rectangle.setMap(this.map);
				this.map.polygon.setMap(null);
				this.map.fitBounds(shapeInfo.bounds);

			} else {
				this.map.rectangle.setMap(null);
				this.map.polygon.setMap(null);
			}



			// Show marker.
			this.map.marker.setVisible( true );

			// Center map.
			this.center();
		},

		switchShapeType: function (shapeType) {
			if(shapeType === 'rectangle') {
				this.map.rectangle.setMap(this.map);
				this.map.polygon.setMap(null);
			} else if(shapeType === 'polygon') {
				this.map.rectangle.setMap(null);
				this.map.polygon.setMap(this.map);
			} else {
				this.map.rectangle.setMap(null);
				this.map.polygon.setMap(null);
			}
		},

		center: function(){

			// Find marker position.
			var position = this.map.marker.getPosition();
			if( position ) {
				var lat = position.lat();
				var lng = position.lng();

				// Or find default settings.
			} else {
				var lat = this.get('lat');
				var lng = this.get('lng');
			}

			// Center map.
			this.map.setCenter({
				lat: parseFloat(lat),
				lng: parseFloat(lng)
			});
		},

		initialize: function(){

			// Ensure Google API is loaded and then initialize map.
			withAPI( this.initializeMap.bind(this) );
		},

		initializeMap: function(){

			// Get value ignoring conditional logic status.
			var val = this.getValue();

			// Construct default args.
			var args = acf.parseArgs(val, {
				zoom: this.get('zoom'),
				lat: this.get('lat'),
				lng: this.get('lng'),
				coordinates: this.get('coordinates')
			});

			console.log({args});

			// Create Map.
			var mapArgs = {
				scrollwheel:	false,
				zoom:			parseInt( args.zoom ),
				center:			{
					lat: parseFloat( args.lat ),
					lng: parseFloat( args.lng )
				},
				mapTypeId:		google.maps.MapTypeId.ROADMAP,
				marker:			{
					draggable: 		true,
					raiseOnDrag: 	true
				},
				autocomplete: {}
			};
			mapArgs = acf.applyFilters('google_map_args', mapArgs, this);
			var map = new google.maps.Map( this.$canvas()[0], mapArgs );

			// Create Marker.
			var markerArgs = acf.parseArgs(mapArgs.marker, {
				draggable: 		true,
				raiseOnDrag: 	true,
				map:			map
			});
			markerArgs = acf.applyFilters('google_map_marker_args', markerArgs, this);
			var marker = new google.maps.Marker( markerArgs );

			// Create box
			// Polygon Coordinates
			var shapeInfo = this.getShapeInfo(args.coordinates);
			var polygon;
			var rectangle;

			// Styling & Controls
			polygon = new google.maps.Polygon({
				paths: shapeInfo.paths,
				draggable: true, // turn off if it gets annoying
				editable: true,
				strokeColor: '#2E59FF',
				strokeOpacity: 0.8,
				strokeWeight: 2,
				fillColor: '#2E59FF',
				fillOpacity: 0.35
			});

			rectangle = new google.maps.Rectangle({
				bounds: shapeInfo.bounds,
				draggable: true, // turn off if it gets annoying
				editable: true,
				strokeColor: '#FF0000',
				strokeOpacity: 0.8,
				strokeWeight: 2,
				fillColor: '#FF0000',
				fillOpacity: 0.35
			});

			if(shapeInfo.using === 'polygon') {
				polygon.setMap(map);
				rectangle.setMap(null);
			} else if(shapeInfo.using === 'rectangle') {
				rectangle.setMap(map);
				polygon.setMap(null);
			} else {
				rectangle.setMap(null);
				polygon.setMap(null);
			}

			// Maybe Create Autocomplete.
			var autocomplete = false;
			if( acf.isset(google, 'maps', 'places', 'Autocomplete') ) {
				var autocompleteArgs = mapArgs.autocomplete || {};
				autocompleteArgs = acf.applyFilters('google_map_autocomplete_args', autocompleteArgs, this);
				autocomplete = new google.maps.places.Autocomplete( this.$search()[0], autocompleteArgs );
				autocomplete.bindTo('bounds', map);
			}

			// Add map events.
			this.addMapEvents( this, map, marker, autocomplete, polygon, rectangle, shapeInfo.using );

			// Append references.
			map.acf = this;
			map.marker = marker;
			map.polygon = polygon;
			map.rectangle = rectangle;
			map.autocomplete = autocomplete;
			map.shapeType = shapeInfo.using;
			this.map = map;

			// Set position.
			if( val ) {
				this.setPosition( val.lat, val.lng, null );
			}

			/**
			 * Fires immediately after the Google Map has been initialized.
			 *
			 * @date	12/02/2014
			 * @since	5.0.0
			 *
			 * @param	object map The Google Map isntance.
			 * @param	object marker The Google Map marker isntance.
			 * @param	object field The field instance.
			 */
			acf.doAction('google_map_init', map, marker, this);
		},

		addMapEvents: function( field, map, marker, autocomplete, polygon, rectangle, using ){

			// Click map.
			google.maps.event.addListener( map, 'click', function( e ) {
				var lat = e.latLng.lat();
				var lng = e.latLng.lng();
				field.searchPosition( lat, lng );
			});

			// Drag marker.
			google.maps.event.addListener( marker, 'dragend', function(){
				var lat = this.getPosition().lat();
				var lng = this.getPosition().lng();
				field.searchPosition( lat, lng );
			});

			// Autocomplete search.
			if( autocomplete ) {
				google.maps.event.addListener(autocomplete, 'place_changed', function() {
					var place = this.getPlace();
					field.searchPlace( place );
				});
			}

			// Detect zoom change.
			/*
			google.maps.event.addListener( map, 'zoom_changed', function(){
				var val = field.val();
				if( val ) {
					val.zoom = map.getZoom();
					field.setValue( val, true );
				}
			});*/
		},

		searchPosition: function( lat, lng ) {
			//console.log('searchPosition', lat, lng );

			// Start Loading.
			this.setState( 'loading' );

			// Query Geocoder.
			var latLng = { lat: lat, lng: lng };
			geocoder.geocode({ location: latLng }, function( results, status ){
				//console.log('searchPosition', arguments );

				// End Loading.
				this.setState( '' );

				// Status failure.
				if( status !== 'OK' ) {
					this.showNotice({
						text: acf.__('Location not found: %s').replace('%s', status),
						type: 'warning'
					});

					// Success.
				} else {
					var val = this.parseResult( results[0] );

					// Update value.
					this.val( val );
				}

			}.bind( this ));
		},

		searchPlace: function( place ){
			console.log('searchPlace', place );

			// Ignore empty search.
			if( !place || !place.name ) {
				return;
			}

			// No geometry (Custom address search).
			if( !place.geometry ) {
				return this.searchAddress( place.name );
			}

			// Parse place.
			var val = this.parseResult( place );

			// Update value.

			this.val( val );
		},

		searchAddress: function( address ){
			//console.log('searchAddress', address );

			// Bail early if no address.
			if( !address ) {
				return;
			}

			// Allow "lat,lng" search.
			var latLng = address.split(',');
			if( latLng.length == 2 ) {
				var lat = parseFloat(latLng[0]);
				var lng = parseFloat(latLng[1]);
				if( lat && lng ) {
					return this.searchPosition( lat, lng );
				}
			}

			// Start Loading.
			this.setState( 'loading' );

			// Query Geocoder.
			geocoder.geocode({ address: address }, function( results, status ){
				//console.log('searchPosition', arguments );

				// End Loading.
				this.setState( '' );

				// Status failure.
				if( status !== 'OK' ) {
					this.showNotice({
						text: acf.__('Location not found: %s').replace('%s', status),
						type: 'warning'
					});

					// Success.
				} else {
					var val = this.parseResult( results[0] );

					// Override address data with parameter allowing custom address to be defined in search.
					val.address = address;

					// Update value.
					this.val( val );
				}

			}.bind( this ));
		},

		searchLocation: function(){
			//console.log('searchLocation' );

			// Check HTML5 geolocation.
			if( !navigator.geolocation ) {
				return alert( acf.__('Sorry, this browser does not support geolocation') );
			}

			// Start Loading.
			this.setState( 'loading' );

			// Query Geolocation.
			navigator.geolocation.getCurrentPosition(

				// Success.
				function( results ){

					// End Loading.
					this.setState( '' );

					// Search position.
					var lat = results.coords.latitude;
					var lng = results.coords.longitude;
					this.searchPosition( lat, lng );

				}.bind(this),

				// Failure.
				function( error ){
					this.setState( '' );
				}.bind(this)
			);
		},

		/**
		 * parseResult
		 *
		 * Returns location data for the given GeocoderResult object.
		 *
		 * @date	15/10/19
		 * @since	5.8.6
		 *
		 * @param	object obj A GeocoderResult object.
		 * @return	object
		 */
		parseResult: function( obj ) {



			var coordinates = null;
			if(obj && obj.geometry.viewport) {
				var viewport = obj.geometry.viewport;
				//var line = turf.lineString([[viewport.getSouthWest().lng(), viewport.getSouthWest().lat()], [viewport.getNorthEast().lng(), viewport.getNorthEast().lat()]]);
				//var bbox = turf.bbox(line);
				//var bboxPolygon = turf.bboxPolygon(bbox);
				//console.log(bboxPolygon.geometry.coordinates);
				coordinates = [[viewport.getSouthWest().lng(), viewport.getSouthWest().lat()], [viewport.getNorthEast().lng(), viewport.getNorthEast().lat()]];
			}

			// Construct basic data.
			var result = {
				address: obj.formatted_address,
				lat: obj.geometry.location.lat(),
				lng: obj.geometry.location.lng(),
				coordinates
			};

			// Add zoom level.
			result.zoom = this.map.getZoom();

			// Add place ID.
			if( obj.place_id ) {
				result.place_id = obj.place_id;
			}

			// Create search map for address component data.
			var map = {
				street_number: [ 'street_number' ],
				street_name: [ 'street_address', 'route' ],
				city: [ 'locality' ],
				state: [
					'administrative_area_level_1',
					'administrative_area_level_2',
					'administrative_area_level_3',
					'administrative_area_level_4',
					'administrative_area_level_5'
				],
				post_code: [ 'postal_code' ],
				country: [ 'country' ]
			};

			// Loop over map.
			for( var k in map ) {
				var keywords = map[ k ];

				// Loop over address components.
				for( var i = 0; i < obj.address_components.length; i++ ) {
					var component = obj.address_components[ i ];
					var component_type = component.types[0];

					// Look for matching component type.
					if( keywords.indexOf(component_type) !== -1 ) {

						// Append to result.
						result[ k ] = component.long_name;

						// Append short version.
						if( component.long_name !== component.short_name ) {
							result[ k + '_short' ] = component.short_name;
						}
					}
				}
			}

			/**
			 * Filters the parsed result.
			 *
			 * @date	18/10/19
			 * @since	5.8.6
			 *
			 * @param	object result The parsed result value.
			 * @param	object obj The GeocoderResult object.
			 */
			console.log(acf.applyFilters('google_map_result', result, obj, this.map, this));
			return acf.applyFilters('google_map_result', result, obj, this.map, this);
		},

		onClickClear: function(){
			this.val( false );
		},

		onClickLocate: function(){
			this.searchLocation();
		},

		onClickSearch: function(){
			this.searchAddress( this.$search().val() );
		},

		onFocusSearch: function( e, $el ){
			this.setState( 'searching' );
		},

		onChangeType : function (e) {
			this.map.shapeType = e.currentTarget.id;
			this.switchShapeType(this.map.shapeType);
		},

		onBlurSearch: function( e, $el ){

			// Get saved address value.
			var val = this.val();
			var address = val ? val.address : '';

			// Remove 'is-searching' if value has not changed.
			if( $el.val() === address ) {
				this.setState( 'default' );
			}
		},

		onKeyupSearch: function( e, $el ){

			// Clear empty value.
			if( !$el.val() ) {
				this.val( false );
			}
		},

		// Prevent form from submitting.
		onKeydownSearch: function( e, $el ){
			if( e.which == 13 ) {
				e.preventDefault();
				$el.blur();
			}
		},

		// Center map once made visible.
		onShow: function(){
			if( this.map ) {
				this.setTimeout( this.center );
			}
		},
	});

	acf.registerFieldType( Field );

	// Vars.
	var loading = false;
	var geocoder = false;

	/**
	 * withAPI
	 *
	 * Loads the Google Maps API library and troggers callback.
	 *
	 * @date	28/3/19
	 * @since	5.7.14
	 *
	 * @param	function callback The callback to excecute.
	 * @return	void
	 */

	function withAPI( callback ) {

		// Check if geocoder exists.
		if( geocoder ) {
			return callback();
		}

		// Check if geocoder API exists.
		if( acf.isset(window, 'google', 'maps', 'Geocoder') ) {
			geocoder = new google.maps.Geocoder();
			return callback();
		}

		// Geocoder will need to be loaded. Hook callback to action.
		acf.addAction( 'google_map_api_loaded', callback );

		// Bail early if already loading API.
		if( loading ) {
			return;
		}

		// load api
		var url = acf.get('google_map_api');
		if( url ) {

			// Set loading status.
			loading = true;

			// Load API
			$.ajax({
				url: url,
				dataType: 'script',
				cache: true,
				success: function(){
					geocoder = new google.maps.Geocoder();
					acf.doAction('google_map_api_loaded');
				}
			});
		}
	}

})(jQuery);
