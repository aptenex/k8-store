# WPGraphQL Gutenberg

Query gutenberg blocks through wp-graphql

-   <a href="https://wp-graphql-gutenberg.netlify.app/" target="_blank">Usage Docs</a>
-   <a href="https://join.slack.com/t/wp-graphql/shared_invite/zt-3vloo60z-PpJV2PFIwEathWDOxCTTLA" target="_blank">Join our community through WpGraphQL Slack</a>

## Install

-   Requires PHP 7.0+
-   Requires wp-graphql 0.9.0+
-   Requires WordPress 5.4+

### Quick Install

Download and install like any WordPress plugin.
[Details here.](https://wp-graphql-gutenberg.netlify.app/getting-started/installation)
