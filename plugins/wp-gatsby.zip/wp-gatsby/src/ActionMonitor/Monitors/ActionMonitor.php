<?php

namespace WPGatsby\ActionMonitor\Monitors;

class ActionMonitor extends Monitor {
	public function init() { }
}
