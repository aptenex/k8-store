import * as React from 'react';
import Field from './Field';
import { SimpleGrid } from '@chakra-ui/react';
import { useMemo } from 'react';

function FieldOrFields({field, ...rest}) {
  return (
    <>
      {Array.isArray(field) ? (
        <SimpleGrid w="100%" columns={{base: 1, lg: field.length}} spacing={6}>
          {field.map((f, fi) => (
            <Field key={fi} {...f} {...rest}/>
          ))}
        </SimpleGrid>
      ) : (
        <Field {...field} {...rest}/>
      )}
    </>
  )
}

export default function Fields({fields, ...rest}) {
  return (
    <>
      {fields.map((field, i) => (
        <FieldOrFields {...rest} field={field} key={i}/>
      ))}
    </>
  );
};
