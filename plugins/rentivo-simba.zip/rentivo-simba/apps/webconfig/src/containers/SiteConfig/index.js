import * as React from 'react';
import SubPage from '../../components/SubPage';
import Overview from './Overview';

const navLinks = [
  {
    slug: `overview`,
    label: `Overview`,
    component: Overview
  },
  {
    slug: `design`,
    label: `Design`,
    component: () => <div>Goodbye</div>
  }
];

export default function SiteConfig() {
  return (
    <SubPage title="Site Config" navLinks={navLinks}/>
  )
};
