import { combineReducers } from 'redux';
import siteConfig from './siteConfig';

export default combineReducers({
  siteConfig
});
