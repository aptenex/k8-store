<?php
/**
 * barcelona functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package barcelona
 */

if ( ! function_exists( 'barcelona_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.

	 */
	function barcelona_setup() {

        add_theme_support( 'align-wide' );

        add_theme_support( 'post-thumbnails' );

        register_nav_menus(
            array(
                'primary' => __( 'Primary Menu' ),
                'secondary' => __( 'Secondary Menu' ),
                'footer-col-one' => __( 'Footer Column One' ),
                'footer-col-two' => __( 'Footer Column Two' ),
                'footer-col-three' => __( 'Footer Column Three' ),
                'footer-col-four' => __( 'Footer Column Four' ),
                'footer-bottom' => __( 'Footer Bottom' )
            )
        );
	}
endif;

add_action( 'after_setup_theme', 'barcelona_setup' );

/**
 * Enqueue scripts and styles.
 */
function barcelona_scripts() {
	wp_enqueue_style( 'barcelona-style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'barcelona_scripts' );

require get_template_directory() . '/inc/acf.php';

//$languages = pll_languages_list();
//print_r($languages);


