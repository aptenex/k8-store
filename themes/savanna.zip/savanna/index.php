<?php

// Redirect to actual live site...
$options = get_field('site_config', 'options');
if($options) {
    $siteConfig = json_decode(get_field('site_config', 'options'));
    if($siteConfig->websiteUrl) {
        header("Location: " . $siteConfig->websiteUrl);
        exit();
    }
}

/*
$languages = pll_the_languages(array('raw'=>1));
foreach ($languages as &$lang) {
    $localePieces = explode("-", $lang['locale']);
    $code = $localePieces[0];
    $friendlyLocale = $code . '_' . $localePieces[1];

    $translations = get_field('translations', 'options_' . $friendlyLocale);
    echo "------ $friendlyLocale TRANSLATIONS -------";
    echo "<pre>";
    print_r($translations);
    echo "</pre>";
}*/

/*
$optionsTranslationsEn = get_field('translations', 'options_en_GB');
$optionsTranslationsIt = get_field('translations', 'options_it_IT');
$optionsTranslationsDefault = get_field('translations', 'options');

$optionsSiteConfig = get_field('site_config', 'options');


echo "------ ENGLISH TRANSLATIONS -------";
echo "<pre>";
print_r($optionsTranslationsEn);
echo "</pre>";

echo "------ ITALIAN TRANSLATIONS -------";
echo "<pre>";
print_r($optionsTranslationsIt);
echo "</pre>";

echo "------ GENERAL TRANSLATIONS -------";
echo "<pre>";
print_r($optionsTranslationsIt);
echo "</pre>";

echo "------ SITE CONFIG -------";
echo "<pre>";
print_r($optionsSiteConfig);
echo "</pre>";
*/
