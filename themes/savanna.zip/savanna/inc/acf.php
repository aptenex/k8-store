<?php
add_action( 'acf/init', 'acf_init_function');
function acf_init_function() {
    if( function_exists('acf_add_options_page') ) {
        //acf_add_options_page();
        //acf_add_options_sub_page('Theme');
    }
}

add_filter( 'acf/settings/load_json', 'acf_json_load_point_function' );
function acf_json_load_point_function( $paths ) {
    unset($paths[0]);
    $paths[] = get_template_directory() . '/acf-json';
    return $paths;
}

/*
add_filter( 'acf/settings/save_json', 'acf_json_save_point_function' );
function acf_json_save_point_function( $path ) {
    $path = get_template_directory() . '/acf-json';
    return $path;
}*/
